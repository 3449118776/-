// 模块加载器 — 兼容 Node.js 和 Cloudflare Workers
// Node.js: 从文件系统读取 markdown 文件
// Workers: 从预打包的 modules-bundle.js 加载

let _bundledModules = null;

function getBundledModules() {
  if (_bundledModules) return _bundledModules;
  try {
    _bundledModules = require('./modules-bundle.js');
  } catch {
    _bundledModules = {};
  }
  return _bundledModules;
}

function parseSections(content) {
  const sections = [];
  const lines = content.split('\n');

  let currentSection = null;
  let currentSubsection = null;
  let currentText = [];
  let inCodeBlock = false;
  let inTable = false;
  let tableHeaders = [];
  let tableRows = [];

  function flushSection() {
    if (currentSection) {
      const section = {
        title: currentSection,
        subsections: [],
        text: currentText.join('\n').trim()
      };
      if (currentSubsection) {
        section.subsections.push({
          title: currentSubsection.subtitle,
          text: currentSubsection.text.join('\n').trim(),
          tables: currentSubsection.tables || [],
          items: currentSubsection.items || []
        });
        currentSubsection = null;
      }
      sections.push(section);
    }
    currentSection = null;
    currentText = [];
  }

  function flushSubsection() {
    if (currentSubsection && currentSection) {
      const idx = sections.findIndex(s => s.title === currentSection);
      if (idx >= 0) {
        sections[idx].subsections.push({
          title: currentSubsection.subtitle,
          text: currentSubsection.text.join('\n').trim(),
          tables: currentSubsection.tables || [],
          items: currentSubsection.items || []
        });
      }
    }
    currentSubsection = null;
  }

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    if (line.startsWith('```')) {
      inCodeBlock = !inCodeBlock;
      continue;
    }
    if (inCodeBlock) continue;

    if (line.startsWith('|') && line.includes('|')) {
      if (!inTable) {
        inTable = true;
        tableHeaders = line.split('|').map(c => c.trim()).filter(Boolean);
        continue;
      }
      if (line.match(/^\|[\s\-:]+\|/)) continue;
      if (inTable) {
        const cells = line.split('|').map(c => c.trim()).filter(Boolean);
        tableRows.push(cells);
        continue;
      }
    } else {
      if (inTable && tableRows.length > 0) {
        const tableData = { headers: tableHeaders, rows: tableRows };
        inTable = false;
        tableHeaders = [];
        tableRows = [];
        if (currentSubsection) {
          if (!currentSubsection.tables) currentSubsection.tables = [];
          currentSubsection.tables.push(tableData);
        }
      }
      inTable = false;
    }

    if (line.startsWith('# ')) {
      flushSubsection();
      flushSection();
      currentSection = line.replace(/^# /, '').trim();
    } else if (line.startsWith('## ')) {
      flushSubsection();
      const subtitle = line.replace(/^## /, '').trim();
      currentSubsection = { subtitle, text: [], tables: [], items: [] };
    } else if (line.startsWith('### ')) {
      flushSubsection();
      const subtitle = line.replace(/^### /, '').trim();
      currentSubsection = { subtitle, text: [], tables: [], items: [] };
    } else {
      if (currentSubsection) {
        currentSubsection.text.push(line);
      } else {
        currentText.push(line);
      }
    }
  }

  flushSubsection();
  flushSection();

  return sections;
}

function loadModule(moduleFile) {
  const bundled = getBundledModules();

  if (bundled[moduleFile]) {
    const content = bundled[moduleFile];
    const sections = parseSections(content);
    return { filePath: moduleFile, sections, rawLength: content.length, source: 'bundled' };
  }

  try {
    const fs = require('fs');
    const path = require('path');
    const filePath = path.join(path.resolve(__dirname, '../../modules'), moduleFile);
    if (!fs.existsSync(filePath)) {
      return { error: `模块文件不存在: ${moduleFile}`, sections: [] };
    }
    const content = fs.readFileSync(filePath, 'utf-8');
    const sections = parseSections(content);
    return { filePath, sections, rawLength: content.length, source: 'filesystem' };
  } catch {
    return { error: `模块加载失败: ${moduleFile}`, sections: [] };
  }
}

function loadAllModules() {
  const bundled = getBundledModules();
  const modules = {};

  for (const [file, content] of Object.entries(bundled)) {
    modules[file] = { filePath: file, sections: parseSections(content), rawLength: content.length, source: 'bundled' };
  }

  if (Object.keys(modules).length > 0) return modules;

  try {
    const fs = require('fs');
    const path = require('path');
    const MODULES_DIR = path.resolve(__dirname, '../../modules');
    const files = fs.readdirSync(MODULES_DIR).filter(f => f.endsWith('.md'));
    for (const file of files) {
      modules[file] = loadModule(file);
    }
  } catch {}

  return modules;
}

module.exports = { loadModule, loadAllModules, parseSections };
