// 文心笔匠 MCP Server — HTTP/SSE 入口（云端部署用）
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { McpServer } = require('@modelcontextprotocol/sdk/server/mcp.js');
const { StreamableHTTPServerTransport } = require('@modelcontextprotocol/sdk/server/streamableHttp.js');

const { registerWorldBuildingTools } = require('./tools/world-building');
const { registerCharacterDesignTools } = require('./tools/character-design');
const { registerPlotArchitectureTools } = require('./tools/plot-architecture');
const { registerTextQualityTools } = require('./tools/text-quality');
const { registerWebNovelTools } = require('./tools/web-novel');
const { registerAdvancedTools } = require('./tools/advanced-tools');
const { registerMemoryTools } = require('./tools/memory-system');

const PORT = parseInt(process.env.PORT || '3000', 10);
const DATA_DIR = process.env.DATA_DIR || './data';
const MCP_PATH = process.env.MCP_PATH || '/mcp';

const absDataDir = path.resolve(DATA_DIR);
if (!fs.existsSync(absDataDir)) {
  fs.mkdirSync(absDataDir, { recursive: true });
}

const server = new McpServer({
  name: 'wenxin-bijiang-mcp',
  version: '1.0.0'
}, {
  capabilities: { tools: {} }
});

registerWorldBuildingTools(server);
registerCharacterDesignTools(server);
registerPlotArchitectureTools(server);
registerTextQualityTools(server);
registerWebNovelTools(server);
registerAdvancedTools(server);
registerMemoryTools(server);

const transport = new StreamableHTTPServerTransport({
  sessionIdGenerator: () => crypto.randomUUID()
});

const httpServer = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Mcp-Session-Id, Authorization');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);

  if (url.pathname === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'ok',
      name: 'wenxin-bijiang-mcp',
      version: '1.0.0',
      tools: Object.keys(server._registeredTools).length
    }));
    return;
  }

  if (url.pathname === MCP_PATH) {
    try {
      await transport.handleRequest(req, res, undefined);
    } catch (err) {
      console.error('[wenxin-bijiang] 请求处理错误:', err.message);
      if (!res.headersSent) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Internal server error', message: err.message }));
      }
    }
    return;
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Not found' }));
});

async function main() {
  // 启动时从 R2 同步数据（若已配置）
  let r2 = null;
  try { r2 = require('./storage/r2-adapter'); } catch {}
  if (r2 && r2.isConfigured()) {
    console.error('[wenxin-bijiang] 检测到 R2 配置，正在从远端同步...');
    const syncResult = await r2.syncFromR2(absDataDir);
    console.error(`[wenxin-bijiang] R2 同步: ${syncResult.message}`);
  }

  await server.connect(transport);
  console.error(`[wenxin-bijiang] MCP Server 已绑定 Streamable HTTP 传输`);
  console.error(`[wenxin-bijiang] 已注册 ${Object.keys(server._registeredTools).length} 个工具`);

  httpServer.listen(PORT, () => {
    console.error(`[wenxin-bijiang] HTTP Server 已启动: http://0.0.0.0:${PORT}`);
    console.error(`[wenxin-bijiang] MCP 端点: POST ${MCP_PATH}`);
    console.error(`[wenxin-bijiang] 健康检查: GET /health`);
    console.error(`[wenxin-bijiang] 数据目录: ${absDataDir}`);
  });
}

main().catch(err => {
  console.error('[wenxin-bijiang] 启动失败:', err);
  process.exit(1);
});

process.on('SIGTERM', async () => {
  console.error('[wenxin-bijiang] 收到 SIGTERM，正在关闭...');
  await server.close();
  httpServer.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.error('[wenxin-bijiang] 收到 SIGINT，正在关闭...');
  await server.close();
  httpServer.close();
  process.exit(0);
});
