// 文心笔匠 MCP Server — 主入口
const { McpServer } = require('@modelcontextprotocol/sdk/server/mcp.js');
const { StdioServerTransport } = require('@modelcontextprotocol/sdk/server/stdio.js');
const z = require('zod');

const { registerWorldBuildingTools } = require('./tools/world-building');
const { registerCharacterDesignTools } = require('./tools/character-design');
const { registerPlotArchitectureTools } = require('./tools/plot-architecture');
const { registerTextQualityTools } = require('./tools/text-quality');
const { registerWebNovelTools } = require('./tools/web-novel');
const { registerAdvancedTools } = require('./tools/advanced-tools');
const { registerMemoryTools } = require('./tools/memory-system');

const server = new McpServer({
  name: 'wenxin-bijiang-mcp',
  version: '1.0.0'
}, {
  capabilities: {
    tools: {}
  }
});

// 注册全部工具
registerWorldBuildingTools(server);
registerCharacterDesignTools(server);
registerPlotArchitectureTools(server);
registerTextQualityTools(server);
registerWebNovelTools(server);
registerAdvancedTools(server);
registerMemoryTools(server);

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error('文心笔匠 MCP Server 已启动');
}

main().catch(err => {
  console.error('MCP Server 启动失败:', err);
  process.exit(1);
});
