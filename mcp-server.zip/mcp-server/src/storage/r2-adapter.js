// R2 存储适配器 — 通过 S3 兼容 API 与 Cloudflare R2 交互
const { S3Client, GetObjectCommand, PutObjectCommand, ListObjectsV2Command, DeleteObjectCommand } = require('@aws-sdk/client-s3');
const fs = require('fs');
const path = require('path');

let _client = null;
let _bucket = null;

function getClient() {
  if (_client) return _client;

  const accountId = process.env.R2_ACCOUNT_ID;
  const accessKeyId = process.env.R2_ACCESS_KEY_ID;
  const secretAccessKey = process.env.R2_SECRET_ACCESS_KEY;
  _bucket = process.env.R2_BUCKET || 'wenxin-bijiang-memory';

  if (!accountId || !accessKeyId || !secretAccessKey) {
    throw new Error('R2 配置不完整：需要 R2_ACCOUNT_ID, R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY');
  }

  _client = new S3Client({
    region: 'auto',
    endpoint: `https://${accountId}.r2.cloudflarestorage.com`,
    credentials: {
      accessKeyId,
      secretAccessKey,
    },
    forcePathStyle: true,
  });

  return _client;
}

function isConfigured() {
  return !!(process.env.R2_ACCOUNT_ID && process.env.R2_ACCESS_KEY_ID && process.env.R2_SECRET_ACCESS_KEY);
}

// 上传文件到 R2
async function upload(filePath, key) {
  const client = getClient();
  const body = fs.readFileSync(filePath);
  await client.send(new PutObjectCommand({
    Bucket: _bucket,
    Key: key,
    Body: body,
    ContentType: 'application/json',
  }));
}

// 从 R2 下载文件
async function download(key) {
  const client = getClient();
  try {
    const response = await client.send(new GetObjectCommand({
      Bucket: _bucket,
      Key: key,
    }));
    const body = await response.Body.transformToString('utf-8');
    return body;
  } catch (err) {
    if (err.name === 'NoSuchKey') return null;
    throw err;
  }
}

// 列出所有对象
async function listAll(prefix = '') {
  const client = getClient();
  const response = await client.send(new ListObjectsV2Command({
    Bucket: _bucket,
    Prefix: prefix,
  }));
  return (response.Contents || []).map(obj => ({
    key: obj.Key,
    size: obj.Size,
    lastModified: obj.LastModified,
  }));
}

// 删除对象
async function remove(key) {
  const client = getClient();
  await client.send(new DeleteObjectCommand({
    Bucket: _bucket,
    Key: key,
  }));
}

// 同步：启动时从 R2 拉取全部数据到本地
async function syncFromR2(localDir) {
  if (!isConfigured()) {
    return { synced: 0, message: 'R2 未配置，使用本地存储' };
  }

  try {
    const objects = await listAll();
    let count = 0;

    for (const obj of objects) {
      const content = await download(obj.key);
      if (content) {
        const localPath = path.join(localDir, obj.key);
        const dir = path.dirname(localPath);
        if (!fs.existsSync(dir)) {
          fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(localPath, content, 'utf-8');
        count++;
      }
    }

    return { synced: count, message: `从 R2 同步了 ${count} 个文件` };
  } catch (err) {
    return { synced: 0, message: `R2 同步失败: ${err.message}`, error: err.message };
  }
}

// 同步：写入后上传到 R2
async function syncToR2(localPath, key) {
  if (!isConfigured()) return { uploaded: false };
  if (!fs.existsSync(localPath)) return { uploaded: false, message: '本地文件不存在' };

  try {
    await upload(localPath, key);
    return { uploaded: true };
  } catch (err) {
    return { uploaded: false, message: `R2 上传失败: ${err.message}` };
  }
}

// 删除远端文件
async function deleteFromR2(key) {
  if (!isConfigured()) return;
  try {
    await remove(key);
  } catch (err) {
    console.error('R2 删除失败:', err.message);
  }
}

module.exports = { isConfigured, syncFromR2, syncToR2, deleteFromR2, listAll };
