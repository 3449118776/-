// D1 记忆存储适配器 — Cloudflare Workers 专用，替代文件系统
let _db = null;

function setDB(db) {
  _db = db;
}

async function loadMemory(workName) {
  if (!_db) throw new Error('D1 database not configured');
  const name = workName || 'default';
  const result = await _db.prepare('SELECT data FROM memory_data WHERE work_name = ?').bind(name).first();
  if (!result) return null;
  try {
    return JSON.parse(result.data);
  } catch {
    return null;
  }
}

async function saveMemory(ms, workName) {
  if (!_db) throw new Error('D1 database not configured');
  const name = workName || 'default';
  const json = JSON.stringify(ms);
  await _db.prepare(
    'INSERT OR REPLACE INTO memory_data (work_name, data, updated_at) VALUES (?, ?, datetime(\'now\'))'
  ).bind(name, json).run();
}

async function deleteMemory(workName) {
  if (!_db) throw new Error('D1 database not configured');
  const name = workName || 'default';
  await _db.prepare('DELETE FROM memory_data WHERE work_name = ?').bind(name).run();
}

async function listWorks() {
  if (!_db) throw new Error('D1 database not configured');
  const result = await _db.prepare('SELECT work_name, updated_at FROM memory_data ORDER BY updated_at DESC').all();
  return (result.results || []).map(r => ({ workName: r.work_name, updatedAt: r.updated_at }));
}

module.exports = { setDB, loadMemory, saveMemory, deleteMemory, listWorks };
