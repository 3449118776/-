// Cloudflare Worker 入口 — 将 Node.js MCP Server 适配到 Workers 运行环境
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { EventEmitter } from 'node:events';
import { registerWorldBuildingTools } from './tools/world-building.js';
import { registerCharacterDesignTools } from './tools/character-design.js';
import { registerPlotArchitectureTools } from './tools/plot-architecture.js';
import { registerTextQualityTools } from './tools/text-quality.js';
import { registerWebNovelTools } from './tools/web-novel.js';
import { registerAdvancedTools } from './tools/advanced-tools.js';
import { initDB } from './tools/memory-system-worker.js';

let _serverPromise = null;
let _dbInitialized = false;

// 在 Worker 中注册记忆系统工具（用 D1 版本替代文件系统版本）
function registerMemoryToolsWorker(server) {
  const memoryWorker = require('./tools/memory-system-worker.js');
  const z = require('zod');

  server.tool(
    'memory_init_work',
    '初始化新作品的记忆库。在开始新作品的创作前调用。',
    { work_name: z.string().describe('作品名称') },
    async ({ work_name }) => {
      const result = await memoryWorker.main({ action: 'init_work', workName: work_name });
      return { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] };
    }
  );

  server.tool(
    'memory_list_works',
    '列出所有已创建的作品记忆库。',
    {},
    async () => {
      const result = await memoryWorker.main({ action: 'list_works' });
      return { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] };
    }
  );

  server.tool(
    'memory_switch_work',
    '切换到指定作品的记忆库。',
    { work_name: z.string().describe('要切换到的作品名称') },
    async ({ work_name }) => {
      const result = await memoryWorker.main({ action: 'switch_work', workName: work_name });
      return { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] };
    }
  );

  server.tool(
    'memory_record_chapter',
    '记录一章的完整记忆。写完一章后必须调用。',
    {
      chapter_index: z.number().describe('章节序号'),
      summary: z.string().describe('本章一句话核心剧情'),
      characters: z.array(z.object({
        name: z.string(), role: z.string().optional(), status: z.string().optional(),
        location: z.string().optional(), emotion: z.string().optional(), milestone: z.string().optional()
      })).optional(),
      foreshadows: z.array(z.object({ text: z.string(), status: z.string().optional() })).optional(),
      items: z.array(z.object({ name: z.string(), owner: z.string().optional(), description: z.string().optional() })).optional(),
      factions: z.array(z.object({ name: z.string(), leader: z.string().optional(), members: z.array(z.string()).optional(), status: z.string().optional() })).optional()
    },
    async (params) => {
      const result = await memoryWorker.main({
        action: 'record_chapter', chapterIdx: params.chapter_index, summary: params.summary,
        characters: params.characters || [], foreshadows: params.foreshadows || [],
        items: params.items || [], factions: params.factions || []
      });
      return { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] };
    }
  );

  server.tool(
    'memory_record_character',
    '记录或更新角色档案信息。',
    {
      name: z.string().describe('角色名称'),
      role: z.enum(['主角', '反派', '配角']).optional().default('配角'),
      chapter: z.number().optional(), status: z.string().optional(),
      location: z.string().optional(), emotion: z.string().optional(), milestone: z.string().optional()
    },
    async (params) => {
      const result = await memoryWorker.main({
        action: 'record_character', name: params.name, role: params.role,
        info: { chapter: params.chapter, status: params.status || '', location: params.location || '', emotion: params.emotion || '', milestone: params.milestone || '' }
      });
      return { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] };
    }
  );

  server.tool(
    'memory_search',
    '搜索记忆库。',
    {
      keyword: z.string().optional(), character_name: z.string().optional(),
      search_type: z.enum(['keyword', 'character', 'foreshadow', 'context'])
    },
    async ({ keyword, character_name, search_type }) => {
      let result;
      switch (search_type) {
        case 'keyword': result = await memoryWorker.main({ action: 'search_by_keyword', keyword }); break;
        case 'character': result = await memoryWorker.main({ action: 'search_character', name: character_name }); break;
        case 'foreshadow': result = await memoryWorker.main({ action: 'search_foreshadows', status: '全部' }); break;
        case 'context': result = await memoryWorker.main({ action: 'get_recent_context', limit: 5 }); break;
        default: result = { success: false, message: '未知搜索类型' };
      }
      return { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] };
    }
  );

  server.tool(
    'memory_check_consistency',
    '执行记忆一致性检查。',
    {},
    async () => {
      const result = await memoryWorker.main({ action: 'check_consistency' });
      return { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] };
    }
  );

  server.tool(
    'memory_get_full_analysis',
    '获取完整记忆分析报告。',
    {},
    async () => {
      const result = await memoryWorker.main({ action: 'full_analysis' });
      return { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] };
    }
  );

  server.tool(
    'memory_load_base',
    '加载当前作品的基础记忆数据。',
    {},
    async () => {
      const result = await memoryWorker.main({ action: 'load_base' });
      return { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] };
    }
  );
}

function getServer() {
  if (_serverPromise) return _serverPromise;

  _serverPromise = (async () => {
    const server = new McpServer({
      name: 'wenxin-bijiang-mcp',
      version: '1.0.0'
    }, { capabilities: { tools: {} } });

    console.error('[worker] 注册工具开始...');
    try { registerWorldBuildingTools(server); console.error('[worker] world-building OK'); } catch (e) { console.error('[worker] world-building FAIL:', e.message, e.stack); }
    try { registerCharacterDesignTools(server); console.error('[worker] character-design OK'); } catch (e) { console.error('[worker] character-design FAIL:', e.message); }
    try { registerPlotArchitectureTools(server); console.error('[worker] plot-architecture OK'); } catch (e) { console.error('[worker] plot-architecture FAIL:', e.message); }
    try { registerTextQualityTools(server); console.error('[worker] text-quality OK'); } catch (e) { console.error('[worker] text-quality FAIL:', e.message); }
    try { registerWebNovelTools(server); console.error('[worker] web-novel OK'); } catch (e) { console.error('[worker] web-novel FAIL:', e.message); }
    try { registerAdvancedTools(server); console.error('[worker] advanced-tools OK'); } catch (e) { console.error('[worker] advanced-tools FAIL:', e.message); }
    try { registerMemoryToolsWorker(server); console.error('[worker] memory-tools OK'); } catch (e) { console.error('[worker] memory-tools FAIL:', e.message, e.stack); }

    const transport = new StreamableHTTPServerTransport({
      sessionIdGenerator: () => crypto.randomUUID()
    });

    await server.connect(transport);
    console.error('[worker] 服务器初始化完成');
    return { transport };
  })();

  return _serverPromise;
}

function createNodeReq(workerRequest, bodyText) {
  const req = new EventEmitter();
  req.method = workerRequest.method;
  const url = new URL(workerRequest.url);
  req.url = url.pathname + url.search;
  req.headers = {};
  for (const [k, v] of workerRequest.headers.entries()) {
    req.headers[k.toLowerCase()] = v;
  }
  queueMicrotask(() => {
    req.emit('data', Buffer.from(bodyText));
    req.emit('end');
  });
  return req;
}

function createNodeRes() {
  let _statusCode = 200;
  const _headers = {};
  const _chunks = [];
  let _resolve;
  const p = new Promise(r => { _resolve = r; });

  const res = {
    get statusCode() { return _statusCode; },
    set statusCode(v) { _statusCode = v; },
    headersSent: false,
    setHeader(name, value) { _headers[name.toLowerCase()] = value; },
    getHeader(name) { return _headers[name.toLowerCase()]; },
    writeHead(code, headers) { _statusCode = code; if (headers) Object.assign(_headers, headers); },
    write(chunk) { if (chunk) _chunks.push(typeof chunk === 'string' ? chunk : chunk.toString()); },
    end(chunk) {
      if (chunk) _chunks.push(typeof chunk === 'string' ? chunk : chunk.toString());
      const rh = new Headers();
      for (const [k, v] of Object.entries(_headers)) rh.set(k, v);
      _resolve(new Response(_chunks.join(''), { status: _statusCode, headers: rh }));
    },
  };
  return { res, responsePromise: p };
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (!_dbInitialized && env.WENXIN_DB) {
      initDB(env.WENXIN_DB);
      _dbInitialized = true;
    }

    if (url.pathname === '/health') {
      return new Response(JSON.stringify({
        status: 'ok', name: 'wenxin-bijiang-mcp', version: '1.0.0',
        tools: 28, runtime: 'cloudflare-workers', db: _dbInitialized ? 'connected' : 'disconnected'
      }), { headers: { 'Content-Type': 'application/json' } });
    }

    if (url.pathname === '/mcp' && request.method === 'POST') {
      console.error('[worker] MCP 请求到达');
      try {
        const bodyText = await request.text();
        console.error('[worker] body 长度:', bodyText.length);
        const { transport } = await getServer();
        console.error('[worker] transport 就绪');
        const req = createNodeReq(request, bodyText);
        console.error('[worker] req 创建完成');
        const { res, responsePromise } = createNodeRes();
        console.error('[worker] res 创建完成');

        try {
          await transport.handleRequest(req, res, undefined);
        } catch (innerErr) {
          console.error('[worker] handleRequest 错误:', innerErr.message, innerErr.stack);
          if (!res.headersSent) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ jsonrpc: '2.0', error: { code: -32603, message: innerErr.message }, id: null }));
          }
        }

        const response = await responsePromise;
        const ch = new Headers(response.headers);
        ch.set('Access-Control-Allow-Origin', '*');
        ch.set('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
        return new Response(response.body, { status: response.status, headers: ch });
      } catch (err) {
        console.error('[wenxin-bijiang] Worker error:', err.message, err.stack);
        return new Response(JSON.stringify({
          jsonrpc: '2.0', error: { code: -32603, message: 'Internal error: ' + err.message }, id: null
        }), { status: 500, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' } });
      }
    }

    if (request.method === 'OPTIONS') {
      return new Response(null, {
        status: 204,
        headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, Mcp-Session-Id, Authorization' }
      });
    }

    return new Response(JSON.stringify({ error: 'Not found' }), {
      status: 404, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
    });
  }
};
