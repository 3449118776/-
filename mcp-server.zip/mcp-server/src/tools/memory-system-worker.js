// Workers 兼容记忆系统 — 轻量 D1 直读直写，提供与 entry_v2 兼容的接口
const d1mem = require('../storage/d1-memory.js');

let _currentWork = null;
let _isInitialized = false;

function initDB(db) {
  d1mem.setDB(db);
  _isInitialized = true;
}

async function main(args) {
  if (!_isInitialized) {
    return { success: false, message: '数据库未初始化，请先配置 D1 绑定' };
  }

  const { action } = args;

  switch (action) {
    case 'init_work': {
      const { workName } = args;
      _currentWork = workName;
      await d1mem.saveMemory({ works: [{ name: workName, createdAt: new Date().toISOString() }] }, workName);
      return { success: true, action, data: null, message: `作品「${workName}」记忆库已初始化并持久化` };
    }

    case 'list_works': {
      const works = await d1mem.listWorks();
      const data = works.map(w => ({ name: w.workName, lastModified: w.updatedAt }));
      return { success: true, action, data, message: `共 ${data.length} 个作品` };
    }

    case 'switch_work': {
      const { workName } = args;
      _currentWork = workName;
      const data = await d1mem.loadMemory(workName);
      if (!data) {
        return { success: false, action, message: `作品「${workName}」不存在，请先 memory_init_work` };
      }
      return { success: true, action, data: { name: workName, lastModified: new Date().toISOString() }, message: `已切换到「${workName}」` };
    }

    case 'load_base': {
      const data = await d1mem.loadMemory(_currentWork);
      if (!data) {
        return { success: false, action, message: '当前作品无记忆数据' };
      }
      return { success: true, action, data, message: '基础记忆已加载' };
    }

    case 'record_chapter': {
      const data = await d1mem.loadMemory(_currentWork) || _emptyMemory();
      if (!data.chapters) data.chapters = [];
      data.chapters.push({
        index: args.chapterIdx,
        summary: args.summary,
        characters: args.characters || [],
        foreshadows: args.foreshadows || [],
        items: args.items || [],
        factions: args.factions || [],
        timestamp: new Date().toISOString()
      });

      // 更新角色档案
      if (args.characters && args.characters.length > 0) {
        if (!data.characterArchive) data.characterArchive = {};
        for (const ch of args.characters) {
          const existing = data.characterArchive[ch.name] || {};
          data.characterArchive[ch.name] = { ...existing, ...ch, lastChapter: args.chapterIdx };
        }
      }

      // 合并伏笔
      if (args.foreshadows && args.foreshadows.length > 0) {
        if (!data.foreshadows) data.foreshadows = [];
        data.foreshadows.push(...args.foreshadows.map(f => ({ ...f, chapter: args.chapterIdx })));
      }

      await d1mem.saveMemory(data, _currentWork);
      return { success: true, action, message: `第 ${args.chapterIdx} 章记忆已记录` };
    }

    case 'record_character': {
      const data = await d1mem.loadMemory(_currentWork) || _emptyMemory();
      if (!data.characterArchive) data.characterArchive = {};
      const existing = data.characterArchive[args.name] || {};
      data.characterArchive[args.name] = {
        ...existing,
        name: args.name,
        role: args.role,
        ...args.info,
        updatedAt: new Date().toISOString()
      };
      await d1mem.saveMemory(data, _currentWork);
      return { success: true, action, message: `角色「${args.name}」档案已更新` };
    }

    case 'search_by_keyword': {
      const data = await d1mem.loadMemory(_currentWork);
      if (!data) return { success: true, action, data: [], message: '无匹配结果' };

      const keyword = args.keyword.toLowerCase();
      const results = [];

      if (data.chapters) {
        for (const ch of data.chapters) {
          if (ch.summary && ch.summary.toLowerCase().includes(keyword)) {
            results.push({ type: 'chapter', index: ch.index, summary: ch.summary });
          }
        }
      }

      if (data.characterArchive) {
        for (const [name, info] of Object.entries(data.characterArchive)) {
          const text = JSON.stringify(info).toLowerCase();
          if (text.includes(keyword)) {
            results.push({ type: 'character', name, info });
          }
        }
      }

      return { success: true, action, data: results, count: results.length, message: `找到 ${results.length} 条匹配` };
    }

    case 'search_character': {
      const data = await d1mem.loadMemory(_currentWork);
      if (!data || !data.characterArchive) {
        return { success: true, action, data: null, message: `未找到角色「${args.name}」` };
      }
      const info = data.characterArchive[args.name];
      if (!info) {
        return { success: true, action, data: null, message: `未找到角色「${args.name}」` };
      }

      const appearances = [];
      if (data.chapters) {
        for (const ch of data.chapters) {
          if (ch.characters && ch.characters.some(c => c.name === args.name)) {
            appearances.push({ chapter: ch.index, summary: ch.summary });
          }
        }
      }

      return { success: true, action, data: { info, appearances }, message: `角色「${args.name}」出场 ${appearances.length} 次` };
    }

    case 'search_foreshadows': {
      const data = await d1mem.loadMemory(_currentWork);
      if (!data || !data.foreshadows) {
        return { success: true, action, data: [], message: '无伏笔记录' };
      }

      let foreshadows = data.foreshadows;
      if (args.status && args.status !== '全部') {
        foreshadows = foreshadows.filter(f => f.status === args.status);
      }

      return { success: true, action, data: foreshadows, count: foreshadows.length, message: `共 ${foreshadows.length} 条伏笔` };
    }

    case 'get_recent_context': {
      const data = await d1mem.loadMemory(_currentWork);
      if (!data || !data.chapters) {
        return { success: true, action, data: { chapters: [], summary: '无记录' }, message: '无近期上下文' };
      }

      const limit = args.limit || 5;
      const recent = data.chapters.slice(-limit);
      const summary = recent.map(c => `第${c.index}章: ${c.summary}`).join('\n');

      return { success: true, action, data: { chapters: recent, summary }, message: `最近 ${recent.length} 章上下文` };
    }

    case 'full_analysis': {
      const data = await d1mem.loadMemory(_currentWork);
      if (!data) return { success: true, action, data: { message: '无数据' }, message: '无记忆数据' };

      const analysis = {
        totalChapters: (data.chapters || []).length,
        totalCharacters: Object.keys(data.characterArchive || {}).length,
        totalForeshadows: (data.foreshadows || []).length,
        characterTrajectories: Object.entries(data.characterArchive || {}).map(([name, info]) => ({
          name,
          role: info.role || '未知',
          lastChapter: info.lastChapter,
          status: info.status || '未知',
          emotion: info.emotion || '未知'
        })),
        foreshadowSummary: (data.foreshadows || []).map(f => ({
          text: f.text,
          status: f.status || '待回收',
          chapter: f.chapter
        }))
      };

      return { success: true, action, data: analysis, message: '完整记忆分析已生成' };
    }

    case 'check_consistency': {
      const data = await d1mem.loadMemory(_currentWork);
      if (!data || !data.chapters) {
        return { success: true, action, data: { issues: [], score: 100 }, message: '记忆一致性=100%，无问题' };
      }

      const issues = [];

      // 检查角色失踪
      if (data.characterArchive) {
        for (const [name, info] of Object.entries(data.characterArchive)) {
          const lastChapter = info.lastChapter;
          const totalChapters = data.chapters.length;
          if (lastChapter !== undefined && totalChapters - 1 - lastChapter > 10) {
            issues.push({ type: 'character_missing', name, message: `角色「${name}」已 ${totalChapters - 1 - lastChapter} 章未出场` });
          }
        }
      }

      // 检查伏笔过期
      if (data.foreshadows) {
        let total = data.foreshadows.length;
        let resolved = data.foreshadows.filter(f => f.status === '已回收').length;
        let pending = total - resolved;
        if (pending > 0 && total > 5) {
          issues.push({ type: 'foreshadow_stale', message: `共 ${total} 条伏笔，${pending} 条待回收` });
        }
      }

      const score = Math.max(0, 100 - issues.length * 5);

      return {
        success: true,
        action,
        data: { issues, score, totalIssues: issues.length },
        message: `记忆一致性=${score}%，${issues.length} 个潜在问题`
      };
    }

    default:
      return { success: false, message: `未知操作: ${action}` };
  }
}

function _emptyMemory() {
  return {
    works: _currentWork ? [{ name: _currentWork }] : [],
    chapters: [],
    characterArchive: {},
    foreshadows: [],
    items: [],
    factions: []
  };
}

function getCurrentWorkName() {
  return _currentWork;
}

module.exports = { main, getCurrentWorkName, initDB };
