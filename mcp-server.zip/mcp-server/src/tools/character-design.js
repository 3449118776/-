// 人物设计 MCP 工具
const z = require('zod');
const { loadModule } = require('../module-loader');

function buildFullContent(sections) {
  let out = '';
  for (const s of sections) {
    out += `# ${s.title}\n\n`;
    out += s.text + '\n\n';
    for (const sub of s.subsections) {
      out += `## ${sub.title}\n\n${sub.text}\n\n`;
      for (const t of (sub.tables || [])) {
        out += '| ' + t.headers.join(' | ') + ' |\n';
        out += '|' + t.headers.map(() => '---').join('|') + '|\n';
        for (const row of t.rows) {
          out += '| ' + row.join(' | ') + ' |\n';
        }
        out += '\n';
      }
    }
  }
  return out;
}

function registerCharacterDesignTools(server) {
  const mod = loadModule('02-character-design.md');

  server.tool(
    'character_design_guide',
    '获取人物设计的完整方法论、模板和指导。当用户需要创建或优化小说人物时调用此工具。',
    {
      section: z.enum(['all', 'methodology', 'template', 'flaws', 'hook_intro', 'iceberg_dialogue', 'deep_conflicts', 'collapse_points', 'growth_arc', 'anti_cliche', 'conflict_generator']).default('all').describe('需要获取的具体章节')
    },
    async ({ section }) => {
      if (mod.error) {
        return { content: [{ type: 'text', text: `模块加载失败: ${mod.error}` }] };
      }

      const sections = mod.sections;
      let result = '';

      if (section === 'all' || section === 'methodology') {
        result += buildFullContent(sections.filter(s =>
          ['模块二：人物设计', '引擎级设计：真实缺陷表', '引擎级设计：人物钩子出场法',
           '引擎级设计：冰山对话体系', '引擎级设计：9维深层矛盾层', '引擎级设计：角色崩溃点',
           '引擎级设计：6步成长弧光', '引擎级设计：关系反套路', '人设伪创意检测（生成后自检）'].includes(s.title)
        ));
      }
      if (section === 'all' || section === 'template') {
        result += buildFullContent(sections.filter(s =>
          s.title.includes('附录：人物设计模板')
        ));
      }
      if (section === 'all' || section === 'conflict_generator') {
        result += buildFullContent(sections.filter(s =>
          ['模块十四：深层人设矛盾生成'].includes(s.title)
        ));
      }

      return {
        content: [{ type: 'text', text: result }]
      };
    }
  );

  server.tool(
    'character_deep_conflict_generate',
    '为指定人物生成深层人设矛盾，让人物更立体。基于6个矛盾维度生成2-3层深层矛盾。',
    {
      character_name: z.string().describe('人物名称'),
      surface_traits: z.string().describe('人物的表面性格特质描述'),
      background: z.string().describe('人物的背景故事概要'),
      role: z.enum(['protagonist', 'supporting', 'antagonist']).describe('人物角色类型：主角/配角/反派')
    },
    async ({ character_name, surface_traits, background, role }) => {
      const conflictSection = mod.sections.find(s => s.title === '模块十四：深层人设矛盾生成');
      const deepLayerSection = mod.sections.find(s => s.title === '引擎级设计：9维深层矛盾层');
      const checklist = conflictSection ? buildFullContent([conflictSection]) : '';
      const layerGuide = deepLayerSection ? buildFullContent([deepLayerSection]) : '';

      const roleLabel = role === 'protagonist' ? '主角' : role === 'supporting' ? '配角' : '反派';

      return {
        content: [{
          type: 'text',
          text: `# 深层人设矛盾生成\n\n## 目标人物\n- 名称：${character_name}\n- 角色类型：${roleLabel}\n- 表面特质：${surface_traits}\n- 背景：${background}\n\n---\n\n${layerGuide}\n\n---\n\n${checklist}\n\n请按照以上方法论，为该人物生成至少2-3层深层矛盾，并规划矛盾的发展弧线。`
        }]
      };
    }
  );
}

module.exports = { registerCharacterDesignTools };
