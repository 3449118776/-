// 高级工具 MCP 工具
const z = require('zod');
const { loadModule } = require('../module-loader');

function buildFullContent(sections) {
  let out = '';
  for (const s of sections) {
    out += `# ${s.title}\n\n`;
    out += s.text + '\n\n';
    for (const sub of s.subsections) {
      out += `## ${sub.title}\n\n${sub.text}\n\n`;
      for (const t of (sub.tables || [])) {
        out += '| ' + t.headers.join(' | ') + ' |\n';
        out += '|' + t.headers.map(() => '---').join('|') + '|\n';
        for (const row of t.rows) {
          out += '| ' + row.join(' | ') + ' |\n';
        }
        out += '\n';
      }
    }
  }
  return out;
}

function registerAdvancedTools(server) {
  const mod = loadModule('06-advanced-tools.md');

  server.tool(
    'advanced_tools_guide',
    '获取高级工具的完整方法论。包括因果逻辑检测、RAG记忆检索、12大题材特化写作引擎。',
    {
      section: z.enum(['all', 'causal_logic', 'rag_memory', 'genre_engines']).default('all').describe('需要获取的具体章节'),
      genre: z.string().optional().describe('如果选择 genre_engines，指定题材类型（玄幻/科幻/都市/武侠/历史/言情/悬疑/军事/竞技/游戏/末世/无限流）')
    },
    async ({ section, genre }) => {
      if (mod.error) {
        return { content: [{ type: 'text', text: `模块加载失败: ${mod.error}` }] };
      }

      const sections = mod.sections;
      const allTitles = sections.map(s => s.title);

      const titleMap = {
        all: [],
        causal_logic: allTitles.filter(t => t.includes('因果') || t.includes('逻辑检测')),
        rag_memory: allTitles.filter(t => t.includes('RAG') || t.includes('记忆检索')),
        genre_engines: allTitles.filter(t => t.includes('题材') || t.includes('引擎'))
      };

      const selected = titleMap[section] || [];
      let result = buildFullContent(sections.filter(s => selected.includes(s.title)));

      if (!result) {
        result = buildFullContent(sections);
      }

      const prefix = genre ? `## 题材特化：${genre}\n\n请针对该题材的特点和读者期待进行调整。\n\n---\n\n` : '';

      return {
        content: [{ type: 'text', text: prefix + result }]
      };
    }
  );

  server.tool(
    'causal_logic_check',
    '检测故事情节的因果逻辑一致性。检查事件之间的因果关系是否合理，是否存在逻辑漏洞。',
    {
      plot_description: z.string().describe('需要检测的情节描述'),
      characters_involved: z.string().optional().describe('涉及的角色的动机和能力'),
      world_rules: z.string().optional().describe('相关的世界观规则')
    },
    async ({ plot_description, characters_involved, world_rules }) => {
      const logicSections = mod.sections.filter(s =>
        s.title.includes('因果') || s.title.includes('逻辑检测')
      );
      const guide = buildFullContent(logicSections);

      return {
        content: [{
          type: 'text',
          text: `# 因果逻辑检测\n\n## 待检测情节\n${plot_description}\n\n${characters_involved ? `## 涉及角色\n${characters_involved}\n\n` : ''}${world_rules ? `## 世界观规则\n${world_rules}\n\n` : ''}---\n\n${guide}\n\n请按照以上方法论逐项检测，分析事件因果链是否自洽。`
        }]
      };
    }
  );

  server.tool(
    'genre_engine_apply',
    '应用题材特化写作引擎。根据指定题材，提供该题材专属的写作方法论、常见套路和创新方向。',
    {
      genre: z.enum(['xuanhuan', 'scifi', 'urban', 'wuxia', 'history', 'romance', 'suspense', 'military', 'sports', 'gaming', 'apocalypse', 'infinity']).describe('题材类型'),
      story_concept: z.string().describe('故事的核心概念')
    },
    async ({ genre, story_concept }) => {
      const genreSections = mod.sections.filter(s =>
        s.title.includes('题材') || s.title.includes('引擎')
      );
      const guide = buildFullContent(genreSections);

      const genreLabels = {
        xuanhuan: '玄幻', scifi: '科幻', urban: '都市', wuxia: '武侠',
        history: '历史', romance: '言情', suspense: '悬疑', military: '军事',
        sports: '竞技', gaming: '游戏', apocalypse: '末世', infinity: '无限流'
      };

      return {
        content: [{
          type: 'text',
          text: `# 题材特化写作引擎\n\n## 题材：${genreLabels[genre]}\n\n## 故事概念\n${story_concept}\n\n---\n\n${guide}\n\n请根据以上方法论，对该${genreLabels[genre]}题材的故事提供专属的写作指导、套路参考和创新建议。`
        }]
      };
    }
  );
}

module.exports = { registerAdvancedTools };
