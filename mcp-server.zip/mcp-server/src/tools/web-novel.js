// 网文特化 MCP 工具
const z = require('zod');
const { loadModule } = require('../module-loader');

function buildFullContent(sections) {
  let out = '';
  for (const s of sections) {
    out += `# ${s.title}\n\n`;
    out += s.text + '\n\n';
    for (const sub of s.subsections) {
      out += `## ${sub.title}\n\n${sub.text}\n\n`;
      for (const t of (sub.tables || [])) {
        out += '| ' + t.headers.join(' | ') + ' |\n';
        out += '|' + t.headers.map(() => '---').join('|') + '|\n';
        for (const row of t.rows) {
          out += '| ' + row.join(' | ') + ' |\n';
        }
        out += '\n';
      }
    }
  }
  return out;
}

function registerWebNovelTools(server) {
  const mod = loadModule('05-web-novel.md');

  server.tool(
    'web_novel_guide',
    '获取网文创作的完整方法论。包括平台选型、黄金三章、爽感工程、日更节奏、人设工厂、细纲生成、章尾钩子、卡文突围、数据复盘等10大模块。',
    {
      section: z.enum(['all', 'platform_strategy', 'golden_three', 'satisfaction_engineering', 'daily_rhythm', 'character_factory', 'outline_gen', 'ending_hooks', 'writers_block', 'data_review', 'trope_detect', 'toxin_detect']).default('all').describe('需要获取的具体章节'),
      platform: z.enum(['qidian', 'fanqie', 'jinjiang', 'feilu', 'qimao', 'general']).optional().describe('目标平台')
    },
    async ({ section, platform }) => {
      if (mod.error) {
        return { content: [{ type: 'text', text: `模块加载失败: ${mod.error}` }] };
      }

      const sections = mod.sections;
      const allTitles = sections.map(s => s.title);

      const titleMap = {
        all: [],
        platform_strategy: allTitles.filter(t => t.includes('平台') || t.includes('选型')),
        golden_three: allTitles.filter(t => t.includes('黄金三章') || t.includes('开篇')),
        satisfaction_engineering: allTitles.filter(t => t.includes('爽感') || t.includes('爽点')),
        daily_rhythm: allTitles.filter(t => t.includes('日更') || t.includes('节奏')),
        character_factory: allTitles.filter(t => t.includes('人设工厂') || t.includes('人设')),
        outline_gen: allTitles.filter(t => t.includes('细纲') || t.includes('生成')),
        ending_hooks: allTitles.filter(t => t.includes('章尾钩子') || t.includes('钩子')),
        writers_block: allTitles.filter(t => t.includes('卡文') || t.includes('突围')),
        data_review: allTitles.filter(t => t.includes('数据') || t.includes('复盘')),
        trope_detect: allTitles.filter(t => t.includes('套路检测')),
        toxin_detect: allTitles.filter(t => t.includes('毒点检测'))
      };

      const selected = titleMap[section] || [];
      let result = buildFullContent(sections.filter(s => selected.includes(s.title)));

      if (!result) {
        result = buildFullContent(sections);
      }

      const platformLabel = platform ? { qidian: '起点', fanqie: '番茄', jinjiang: '晋江', feilu: '飞卢', qimao: '七猫', general: '通用' }[platform] : null;
      const prefix = platformLabel ? `## 目标平台：${platformLabel}\n\n请针对该平台的特性和读者偏好进行调整。\n\n---\n\n` : '';

      return {
        content: [{ type: 'text', text: prefix + result }]
      };
    }
  );

  server.tool(
    'golden_three_chapters',
    '设计或分析黄金三章（网文开篇前3章）。包括开篇钩子、爽点安排、人设展示、世界观引入。',
    {
      story_concept: z.string().describe('故事的核心概念/一句话梗概'),
      platform: z.enum(['qidian', 'fanqie', 'jinjiang', 'feilu', 'general']).describe('目标发布平台'),
      target_audience: z.string().optional().describe('目标读者群体描述')
    },
    async ({ story_concept, platform, target_audience }) => {
      const goldenSections = mod.sections.filter(s =>
        s.title.includes('黄金三章') || s.title.includes('开篇')
      );
      const guide = buildFullContent(goldenSections);

      const platformLabel = { qidian: '起点', fanqie: '番茄', jinjiang: '晋江', feilu: '飞卢', general: '通用' }[platform];

      return {
        content: [{
          type: 'text',
          text: `# 黄金三章设计\n\n## 故事概念\n${story_concept}\n\n目标平台：${platformLabel}\n${target_audience ? `目标读者：${target_audience}\n` : ''}\n---\n\n${guide}\n\n请根据以上方法论，为该故事设计黄金三章的详细内容：第1章建立钩子与代入感，第2章展开冲突与世界观，第3章设置悬念推动追读。`
        }]
      };
    }
  );

  server.tool(
    'toxin_detect',
    '检测网文中的毒点（导致读者流失的常见问题）。包括人设崩塌、逻辑硬伤、节奏拖沓、爽点不足、毒点元素等。',
    {
      text: z.string().describe('需要检测的小说文本'),
      platform: z.enum(['qidian', 'fanqie', 'jinjiang', 'feilu', 'general']).optional().describe('目标平台'),
      chapter_number: z.number().optional().describe('当前章节号')
    },
    async ({ text, platform, chapter_number }) => {
      const toxinSections = mod.sections.filter(s =>
        s.title.includes('毒点检测') || s.title.includes('毒点')
      );
      const tropeSections = mod.sections.filter(s =>
        s.title.includes('套路检测')
      );
      const guide = buildFullContent([...toxinSections, ...tropeSections]);

      return {
        content: [{
          type: 'text',
          text: `# 毒点/套路检测\n\n${chapter_number ? `章节：第${chapter_number}章\n` : ''}${platform ? `平台：${platform}\n` : ''}\n## 待检测文本\n${text}\n\n---\n\n${guide}\n\n请按照以上检测清单逐项检查，指出具体毒点和修改建议。`
        }]
      };
    }
  );
}

module.exports = { registerWebNovelTools };
