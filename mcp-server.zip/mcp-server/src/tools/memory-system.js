// 记忆系统 MCP 工具 — 封装 memory_system_v2/engine
const z = require('zod');
const path = require('path');
const fs = require('fs');
const { main, getCurrentWorkName } = require('../../../memory_system_v2/engine/entry_v2');

let _r2 = null;
function getR2() {
  if (_r2 === null) {
    try { _r2 = require('../storage/r2-adapter'); } catch { _r2 = false; }
  }
  return _r2 || null;
}

function getDataDir() {
  return process.env.DATA_DIR || './data';
}

async function syncToR2AfterWrite(workName) {
  const r2 = getR2();
  if (!r2 || !r2.isConfigured()) return;

  const dataDir = getDataDir();
  const fileName = `${workName || 'default'}.json`;
  const localPath = path.join(dataDir, fileName);

  if (fs.existsSync(localPath)) {
    const result = await r2.syncToR2(localPath, fileName);
    if (!result.uploaded && result.message) {
      console.error('[R2]', result.message);
    }
  }
}

function registerMemoryTools(server) {

  server.tool(
    'memory_init_work',
    '初始化新作品的记忆库。在开始新作品的创作前调用。',
    {
      work_name: z.string().describe('作品名称（用作记忆库标识）')
    },
    async ({ work_name }) => {
      const result = await main({ action: 'init_work', workName: work_name });
      if (result.success) await syncToR2AfterWrite(work_name);
      return {
        content: [{ type: 'text', text: JSON.stringify(result, null, 2) }]
      };
    }
  );

  server.tool(
    'memory_list_works',
    '列出所有已创建的作品记忆库。',
    {},
    async () => {
      const result = await main({ action: 'list_works' });
      return {
        content: [{ type: 'text', text: JSON.stringify(result, null, 2) }]
      };
    }
  );

  server.tool(
    'memory_switch_work',
    '切换到指定作品的记忆库。',
    {
      work_name: z.string().describe('要切换到的作品名称')
    },
    async ({ work_name }) => {
      const result = await main({ action: 'switch_work', workName: work_name });
      return {
        content: [{ type: 'text', text: JSON.stringify(result, null, 2) }]
      };
    }
  );

  server.tool(
    'memory_record_chapter',
    '记录一章的完整记忆。包括章节摘要、出场角色状态、新增伏笔、道具变化、势力变化。写完一章后必须调用。',
    {
      chapter_index: z.number().describe('章节序号（从0开始）'),
      summary: z.string().describe('本章一句话核心剧情'),
      characters: z.array(z.object({
        name: z.string(),
        role: z.string().optional(),
        status: z.string().optional(),
        location: z.string().optional(),
        emotion: z.string().optional(),
        milestone: z.string().optional()
      })).optional().describe('本章出场角色及其状态'),
      foreshadows: z.array(z.object({
        text: z.string(),
        status: z.string().optional()
      })).optional().describe('本章新埋的伏笔'),
      items: z.array(z.object({
        name: z.string(),
        owner: z.string().optional(),
        description: z.string().optional()
      })).optional().describe('本章出现/变化的道具'),
      factions: z.array(z.object({
        name: z.string(),
        leader: z.string().optional(),
        members: z.array(z.string()).optional(),
        status: z.string().optional()
      })).optional().describe('本章涉及的势力变化')
    },
    async (params) => {
      const args = {
        action: 'record_chapter',
        chapterIdx: params.chapter_index,
        summary: params.summary,
        characters: params.characters || [],
        foreshadows: params.foreshadows || [],
        items: params.items || [],
        factions: params.factions || []
      };
      const result = await main(args);
      if (result.success) await syncToR2AfterWrite(getCurrentWorkName());
      return {
        content: [{ type: 'text', text: JSON.stringify(result, null, 2) }]
      };
    }
  );

  server.tool(
    'memory_record_character',
    '记录或更新角色档案信息。新角色登场或角色状态发生变化时调用。',
    {
      name: z.string().describe('角色名称'),
      role: z.enum(['主角', '反派', '配角']).optional().default('配角').describe('角色定位'),
      chapter: z.number().optional().describe('出场章节序号'),
      status: z.string().optional().describe('当前状态描述'),
      location: z.string().optional().describe('当前位置'),
      emotion: z.string().optional().describe('当前情绪'),
      milestone: z.string().optional().describe('关键里程碑事件')
    },
    async (params) => {
      const result = await main({
        action: 'record_character',
        name: params.name,
        role: params.role,
        info: {
          chapter: params.chapter,
          status: params.status || '',
          location: params.location || '',
          emotion: params.emotion || '',
          milestone: params.milestone || ''
        }
      });
      if (result.success) await syncToR2AfterWrite(getCurrentWorkName());
      return {
        content: [{ type: 'text', text: JSON.stringify(result, null, 2) }]
      };
    }
  );

  server.tool(
    'memory_search',
    '搜索记忆库。支持关键词检索和角色名检索。',
    {
      keyword: z.string().optional().describe('关键词搜索'),
      character_name: z.string().optional().describe('按角色名搜索'),
      search_type: z.enum(['keyword', 'character', 'foreshadow', 'context']).describe('搜索类型')
    },
    async ({ keyword, character_name, search_type }) => {
      let result;
      switch (search_type) {
        case 'keyword':
          result = await main({ action: 'search_by_keyword', keyword });
          break;
        case 'character':
          result = await main({ action: 'search_character', name: character_name });
          break;
        case 'foreshadow':
          result = await main({ action: 'search_foreshadows', status: '全部' });
          break;
        case 'context':
          result = await main({ action: 'get_recent_context', limit: 5 });
          break;
        default:
          result = { success: false, message: '未知搜索类型' };
      }
      return {
        content: [{ type: 'text', text: JSON.stringify(result, null, 2) }]
      };
    }
  );

  server.tool(
    'memory_check_consistency',
    '执行记忆一致性检查（记忆体检）。检查人设矛盾、伏笔过期、角色失踪、设定冲突等。',
    {},
    async () => {
      const result = await main({ action: 'check_consistency' });
      return {
        content: [{ type: 'text', text: JSON.stringify(result, null, 2) }]
      };
    }
  );

  server.tool(
    'memory_get_full_analysis',
    '获取当前作品的完整记忆分析报告。包括角色轨迹、伏笔状态、情感趋势等。',
    {},
    async () => {
      const result = await main({ action: 'full_analysis' });
      return {
        content: [{ type: 'text', text: JSON.stringify(result, null, 2) }]
      };
    }
  );

  server.tool(
    'memory_load_base',
    '加载当前作品的基础记忆数据（角色/势力/地点/关系/滚动摘要等），用于开始新章节前的上下文回顾。',
    {},
    async () => {
      const result = await main({ action: 'load_base' });
      return {
        content: [{ type: 'text', text: JSON.stringify(result, null, 2) }]
      };
    }
  );
}

module.exports = { registerMemoryTools };
