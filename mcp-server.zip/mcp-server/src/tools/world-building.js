// 世界构建 MCP 工具
const z = require('zod');
const { loadModule } = require('../module-loader');

function buildFullContent(sections) {
  let out = '';
  for (const s of sections) {
    out += `# ${s.title}\n\n`;
    out += s.text + '\n\n';
    for (const sub of s.subsections) {
      out += `## ${sub.title}\n\n${sub.text}\n\n`;
      for (const t of (sub.tables || [])) {
        out += '| ' + t.headers.join(' | ') + ' |\n';
        out += '|' + t.headers.map(() => '---').join('|') + '|\n';
        for (const row of t.rows) {
          out += '| ' + row.join(' | ') + ' |\n';
        }
        out += '\n';
      }
    }
  }
  return out;
}

function registerWorldBuildingTools(server) {
  const mod = loadModule('01-world-building.md');

  server.tool(
    'world_building_guide',
    '获取世界观构建的完整方法论、模板和指导。当用户需要创建或完善小说世界观时调用此工具。',
    {
      section: z.enum(['all', 'methodology', 'template', 'faction_matrix', 'power_system', 'geo_scarcity', 'history', 'deconstruction', 'rule_depth', 'anti_cliche', 'concept_expand', 'logic_check']).default('all').describe('需要获取的具体章节'),
      genre: z.string().optional().describe('题材类型（玄幻/科幻/都市/武侠/历史/言情等），用于针对性指导')
    },
    async ({ section, genre }) => {
      if (mod.error) {
        return { content: [{ type: 'text', text: `模块加载失败: ${mod.error}` }] };
      }

      const sections = mod.sections;
      let result = '';

      if (section === 'all' || section === 'methodology') {
        result += buildFullContent(sections.filter(s =>
          ['模块一：世界观构建', '引擎级设计：势力博弈矩阵', '引擎级设计：力量体系三栏式',
           '引擎级设计：地理资源稀缺性', '引擎级设计：历史事件双版本', '引擎级设计：设定解构法（创新方法论）',
           '引擎级设计：规则深度三问', '伪创意检测（生成后自检）', '世界观反套路清单'].includes(s.title)
        ));
      }
      if (section === 'all' || section === 'template') {
        result += buildFullContent(sections.filter(s =>
          ['附录：世界观构建模板'].includes(s.title)
        ));
      }
      if (section === 'all' || section === 'concept_expand') {
        result += buildFullContent(sections.filter(s =>
          ['模块十一：概念扩展'].includes(s.title)
        ));
      }
      if (section === 'all' || section === 'logic_check') {
        result += buildFullContent(sections.filter(s =>
          ['模块十二：世界逻辑检测'].includes(s.title)
        ));
      }

      const prefix = genre
        ? `## 题材针对性提示\n\n用户选择了「${genre}」题材。请在构建世界观时重点考虑该题材的典型元素与读者期待。\n\n---\n\n`
        : '';

      return {
        content: [{ type: 'text', text: prefix + result }]
      };
    }
  );

  server.tool(
    'world_logic_check',
    '检测世界观设定的逻辑一致性。检查力量体系、经济体系、社会结构、科技/法术水平、地理历史、常识一致性。',
    {
      setting_description: z.string().describe('需要检测的世界观设定描述文本')
    },
    async ({ setting_description }) => {
      const logicSection = mod.sections.find(s => s.title === '模块十二：世界逻辑检测');
      const checklist = logicSection ? buildFullContent([logicSection]) : '';

      return {
        content: [{
          type: 'text',
          text: `# 世界逻辑检测\n\n## 待检测设定\n${setting_description}\n\n---\n\n${checklist}\n\n请按照以上检测维度逐项分析给定设定，指出逻辑漏洞并给出修复建议。`
        }]
      };
    }
  );
}

module.exports = { registerWorldBuildingTools };
