// 正文辅助与质量 MCP 工具
const z = require('zod');
const { loadModule } = require('../module-loader');

function buildFullContent(sections) {
  let out = '';
  for (const s of sections) {
    out += `# ${s.title}\n\n`;
    out += s.text + '\n\n';
    for (const sub of s.subsections) {
      out += `## ${sub.title}\n\n${sub.text}\n\n`;
      for (const t of (sub.tables || [])) {
        out += '| ' + t.headers.join(' | ') + ' |\n';
        out += '|' + t.headers.map(() => '---').join('|') + '|\n';
        for (const row of t.rows) {
          out += '| ' + row.join(' | ') + ' |\n';
        }
        out += '\n';
      }
    }
  }
  return out;
}

// ============================================================================
// 写作规则（从模块中提炼的核心指令，直接嵌入 Prompt）
// ============================================================================

const WRITING_RULES = {
  rhythm: [
    '单句不超过25字，长句立刻拆分',
    '长短句交替：长句铺陈氛围，短句制造紧张',
    '按气口断句，不按语法断句',
    '段落要有视觉分布感，长短交替制造"铺垫—爆发—余震"节奏',
  ],
  showDontTell: [
    '用动作/细节/感官表现情绪，禁止直白情绪词（"他紧张""她很伤心"）',
    '微动作替代形容词：愤怒→指尖发白/咬紧后槽牙，紧张→喉结滚动，暧昧→耳尖泛红',
    '五感描写至少调动2-3种感官，不能只有视觉',
  ],
  dialogue: [
    '答非所问是顶级潜台词：被质问时不要正面解释',
    '用日常事物掩护尖锐矛盾：香水味/茶水温热/衣物褶皱',
    '最关键那句话人物没说出口，但读者都懂',
    '遮住角色名字，读者也能一眼看出是谁在说话',
  ],
  perspective: [
    '禁止读心：角色之间不能直接知道对方在想什么，只能通过动作/表情/语气推测',
    '全程锁定一种主要叙述视角，第三人称有限视角为默认',
    '视角切换必须有铺垫、有不可替代的需求、有明确场景间隔',
  ],
  emotion: [
    '情绪产生后先压住，延迟释放才有冲击力',
    '在情绪高涨时突然塞一句反情绪的话制造撕裂感',
    '爽点公式：蓄力→转折→余韵（众人反应/主角淡然）',
    '虐点公式：建立美好→打碎美好→延迟释放',
  ],
  avoidance: [
    '禁止模板化表达：嘴角勾起、眼神一冷、瞳孔一缩、眉头一皱',
    '禁止AI腔心理：内心五味杂陈、心中百感交集、空气仿佛凝固',
    '禁止空泛推进：命运的齿轮开始转动、一切才刚刚开始',
    '禁止万能形容：极其强大、无比恐怖、深不可测、不可名状',
  ],
  character: [
    '续写前先定状态：此刻角色情绪/身体状态/即时需求是什么',
    '定动机：角色说这句话/做这件事的底层目的（非表面目的）',
    '定边界：以这个角色的性格，什么话会说、什么话绝对不会说',
    '角色可以犹豫、犯错、做蠢事——只要符合人设就比完美人设更真实',
  ],
};

function buildWritingRulesPrompt(rules) {
  const sections = [];
  const labels = {
    rhythm: '## 句式节奏（硬规则）',
    showDontTell: '## Show, Don\'t Tell（硬规则）',
    dialogue: '## 冰山对话体系',
    perspective: '## 视角控制（硬规则）',
    emotion: '## 情绪调动',
    avoidance: '## 禁止表达（黑名单）',
    character: '## 角色扮演',
  };

  for (const key of rules) {
    if (WRITING_RULES[key]) {
      sections.push(labels[key]);
      sections.push(WRITING_RULES[key].map(r => `- ${r}`).join('\n'));
      sections.push('');
    }
  }
  return sections.join('\n');
}

function registerTextQualityTools(server) {
  const mod = loadModule('04-text-quality.md');

  server.tool(
    'text_quality_guide',
    '获取正文写作与质量提升的完整方法论。包括白金作家创作法则、17维质量评估、风格分析、反陈词滥调等。',
    {
      section: z.enum(['all', 'writing_rules', 'quality_eval', 'style_analysis', 'anti_cliche', 'polish', 'expand']).default('all').describe('需要获取的具体章节')
    },
    async ({ section }) => {
      if (mod.error) {
        return { content: [{ type: 'text', text: `模块加载失败: ${mod.error}` }] };
      }

      const sections = mod.sections;
      const allTitles = sections.map(s => s.title);

      const titleMap = {
        all: [],
        writing_rules: allTitles.filter(t => t.includes('白金') || t.includes('创作法则') || t.includes('续写')),
        quality_eval: allTitles.filter(t => t.includes('质量评估') || t.includes('17') || t.includes('评分')),
        style_analysis: allTitles.filter(t => t.includes('风格分析') || t.includes('风格蒸馏')),
        anti_cliche: allTitles.filter(t => t.includes('反陈词滥调') || t.includes('反套路')),
        polish: allTitles.filter(t => t.includes('润色') || t.includes('改写')),
        expand: allTitles.filter(t => t.includes('扩写'))
      };

      const selected = titleMap[section] || [];
      let result = buildFullContent(sections.filter(s => selected.includes(s.title)));

      if (!result) {
        result = buildFullContent(sections);
      }

      return {
        content: [{ type: 'text', text: result }]
      };
    }
  );

  server.tool(
    'quality_evaluation',
    '对给定文本进行17维度质量评估。基于白金作家创作法则，从多个维度评分并给出改进建议。',
    {
      text: z.string().describe('需要评估的小说正文文本'),
      genre: z.string().optional().describe('小说题材类型'),
      chapter_context: z.string().optional().describe('本章在故事中的位置和上下文')
    },
    async ({ text, genre, chapter_context }) => {
      const evalSections = mod.sections.filter(s =>
        s.title.includes('质量评估') || s.title.includes('17') || s.title.includes('评分')
      );
      const ruleSections = mod.sections.filter(s =>
        s.title.includes('白金') || s.title.includes('创作法则')
      );
      const evalGuide = buildFullContent(evalSections);
      const ruleGuide = buildFullContent(ruleSections);

      return {
        content: [{
          type: 'text',
          text: `# 文本质量评估\n\n${genre ? `题材：${genre}\n` : ''}${chapter_context ? `章节上下文：${chapter_context}\n\n` : '\n'}## 待评估文本\n${text}\n\n---\n\n${ruleGuide}\n\n---\n\n${evalGuide}\n\n请按照以上方法论，对该文本进行17维度逐项评分，指出具体问题和改进建议。`
        }]
      };
    }
  );

  server.tool(
    'writing_style_analyze',
    '分析文本的写作风格，进行风格蒸馏。识别作者的语言习惯、句式特征、修辞偏好等。',
    {
      text: z.string().describe('需要分析风格的小说文本'),
      sample_type: z.enum(['single_passage', 'multi_chapter', 'full_work']).default('single_passage').describe('样本类型：单段/多章/全书')
    },
    async ({ text, sample_type }) => {
      const styleSections = mod.sections.filter(s =>
        s.title.includes('风格分析') || s.title.includes('风格蒸馏')
      );
      const guide = buildFullContent(styleSections);

      const typeLabel = sample_type === 'single_passage' ? '单段文本' : sample_type === 'multi_chapter' ? '多章样本' : '全书样本';

      return {
        content: [{
          type: 'text',
          text: `# 写作风格分析\n\n## 样本类型：${typeLabel}\n\n## 待分析文本\n${text}\n\n---\n\n${guide}\n\n请按照以上方法论，从多个维度分析该文本的写作风格特征，并生成风格蒸馏报告。`
        }]
      };
    }
  );

  // ==========================================================================
  // 内容生成工具（Prompt 工程）
  // ==========================================================================

  server.tool(
    'continue_writing',
    '续写正文。根据前文内容、角色状态、上下文信息，按白金作家创作法则输出续写文本。',
    {
      preceding_text: z.string().describe('前文内容（至少包含最近200-500字，提供场景/角色/情绪上下文）'),
      chapter_context: z.string().describe('本章/本段的叙事目标：当前场景是什么？需要推进什么情节？'),
      characters_present: z.string().describe('当前出场的角色及其状态（名称+身份+当前情绪+位置）'),
      foreshadow_hints: z.string().optional().describe('需要在续写中埋伏笔或回收的伏笔信息'),
      target_words: z.number().default(500).describe('目标字数'),
      narrative_perspective: z.enum(['first_person', 'third_person_limited', 'third_person_omniscient', 'multi_pov']).default('third_person_limited').describe('叙事视角'),
      genre: z.string().optional().describe('题材类型'),
    },
    async (params) => {
      const rules = buildWritingRulesPrompt([
        'rhythm', 'showDontTell', 'dialogue', 'perspective', 'emotion', 'avoidance', 'character'
      ]);

      const perspectiveLabels = {
        first_person: '第一人称（"我"视角，代入感最强，信息限于"我"所见所闻）',
        third_person_limited: '第三人称有限视角（最常用，跟主角走，读者知道的=主角感知的）',
        third_person_omniscient: '第三人称全知视角（上帝视角，视野最广，但需有主焦点人物）',
        multi_pov: '多POV（本章只跟一个视角人物，不得章内跳转）',
      };

      return {
        content: [{
          type: 'text',
          text: `# 正文续写

你是一位精通网文创作的小说家。请严格按照以下规则续写正文。

## 叙事视角
${perspectiveLabels[params.narrative_perspective]}

## 前文
${params.preceding_text}

## 本章目标
${params.chapter_context}

## 出场角色
${params.characters_present}
${params.foreshadow_hints ? `\n## 伏笔线索\n${params.foreshadow_hints}` : ''}
${params.genre ? `\n## 题材\n${params.genre}` : ''}

${rules}

## 输出要求
- 目标字数：${params.target_words}字左右
- 只输出正文内容，不要任何说明/注解/标记
- 直接开始叙事，从上一段结束处无缝衔接
- 必须有事件推进（不能纯描写或纯对话停滞不前）
- 章末若有合适时机，埋一个钩子（中断动作/揭露信息/情绪悬置）
`
        }]
      };
    }
  );

  server.tool(
    'polish_text',
    '润色文本。对给定原文进行语言优化：去模板化、增强感官、优化节奏、提升表现力。',
    {
      original_text: z.string().describe('需要润色的原文'),
      polish_focus: z.array(z.enum([
        'de_template', 'sensory_detail', 'rhythm_flow', 'dialogue_depth',
        'emotion_externalize', 'verb_precision', 'show_dont_tell', 'anti_cliche',
        'general'
      ])).default(['general']).describe('润色重点方向（可多选）'),
      preserve_word_count: z.boolean().default(true).describe('是否尽量保持原文字数'),
      target_style: z.string().optional().describe('目标风格描述（如"古龙式冷峻短句""琼瑶式细腻心理"）'),
    },
    async ({ original_text, polish_focus, preserve_word_count, target_style }) => {
      const focusLabels = {
        de_template: '去模板化：替换"嘴角勾起/眼神一冷/瞳孔一缩"等高频套话为具体动作描写',
        sensory_detail: '增强感官：至少调动2-3种感官（视觉/听觉/触觉/嗅觉/味觉），不能只有视觉',
        rhythm_flow: '优化节奏：长短句交替，单句不超25字，按气口断句',
        dialogue_depth: '深化对话：检查是否有答非所问潜台词、日常事物掩护、关键句未说出口的留白',
        emotion_externalize: '情绪外化：将所有直白情绪词（紧张/愤怒/伤心/开心）转为微动作/生理反应',
        verb_precision: '动词精准：替换弱动词（说/看/想/走）为强力精准动词',
        show_dont_tell: 'Show Don\'t Tell：检查所有"告诉读者"的句子，改为"让读者看到"',
        anti_cliche: '反陈词滥调：检查并替换所有套路化表达',
        general: '综合优化：涵盖以上全部方向',
      };

      const focusDesc = polish_focus.map(f => focusLabels[f] || f).join('\n- ');

      const rules = buildWritingRulesPrompt([
        'showDontTell', 'rhythm', 'dialogue', 'avoidance'
      ]);

      return {
        content: [{
          type: 'text',
          text: `# 文本润色

你是一位精通文本打磨的资深编辑。请对以下原文进行润色优化。

## 润色重点
- ${focusDesc}
${target_style ? `\n## 目标风格\n${target_style}` : ''}
${preserve_word_count ? '\n## 字数约束\n尽量保持原文字数，不做大幅删减或扩写，聚焦质量提升。' : '\n## 字数约束\n不做限制，以质量优先。'}

## 原文
${original_text}

${rules}

## 输出格式
- 先输出润色后的完整文本
- 再输出【润色说明】，逐条列出具体改了什么、为什么改（3-5条关键改动即可）
`
        }]
      };
    }
  );

  server.tool(
    'expand_text',
    '扩写片段。在不改变核心情节的前提下丰富细节：环境描写、心理活动、动作细节、对话互动。',
    {
      original_text: z.string().describe('需要扩写的原文（段落或短场景）'),
      expand_dimensions: z.array(z.enum([
        'environment', 'psychology', 'action', 'dialogue', 'interaction',
        'sensory', 'inner_monologue', 'atmosphere'
      ])).default(['psychology', 'sensory']).describe('扩写维度（可多选）'),
      target_words: z.number().default(300).describe('扩写后目标字数（原文+新增）'),
      scene_purpose: z.string().describe('这个场景在故事中的作用（推进剧情/塑造人物/制造悬念/情绪铺垫等）'),
      characters_in_scene: z.string().describe('场景中的人物（名称+当前关系+情绪状态）'),
    },
    async (params) => {
      const dimLabels = {
        environment: '环境描写：空间布局、光线、气味、温度、物品细节——让读者"看到"场景',
        psychology: '心理活动：角色的内心反应、回忆闪回、预期与担忧——让读者"感受到"角色',
        action: '动作细节：肢体语言、微动作、动作的节奏和力度——让每一帧都有画面',
        dialogue: '对话：加一段符合人设的对话，要有潜台词（表面说A实际在说B）',
        interaction: '人物互动：角色之间的眼神交流、身体距离、触碰与回避——关系在细节中',
        sensory: '感官描写：听觉（环境音/呼吸声）、嗅觉（气味记忆）、触觉（质地/温度）、味觉',
        inner_monologue: '内心独白：角色的自我对话、矛盾挣扎、瞬间顿悟',
        atmosphere: '氛围营造：通过环境细节+情感投射，营造统一的情绪基调（压抑/温馨/紧张/空灵）',
      };

      const dimsDesc = params.expand_dimensions.map(d => `- ${d}: ${dimLabels[d] || d}`).join('\n');

      const rules = buildWritingRulesPrompt([
        'showDontTell', 'rhythm', 'emotion', 'avoidance'
      ]);

      return {
        content: [{
          type: 'text',
          text: `# 文本扩写

将以下片段按指定维度丰富细节。不改变核心情节和人物行为，只在原有框架内增加血肉。

## 场景目的
${params.scene_purpose}

## 场景人物
${params.characters_in_scene}

## 扩写维度
${dimsDesc}

## 目标字数
约${params.target_words}字（原文+扩写）

## 原文
${params.original_text}

${rules}

## 输出要求
- 只输出扩写后的完整文本，不要任何说明/注解/标注
- 保持原文的叙事视角和时态不变
- 新增内容必须与原文无缝融合，看不出拼接痕迹
- 每个扩写维度至少体现2处具体细节
`
        }]
      };
    }
  );

  server.tool(
    'rewrite_in_style',
    '风格改写。将原文按目标风格重写，保持核心情节不变，变换语言风格和叙事质感。',
    {
      original_text: z.string().describe('需要改写的原文'),
      target_style: z.string().describe('目标风格描述（如"古龙式冷峻短句，大量留白""琼瑶式细腻心理，情感充沛""番茄爽文快节奏，短句轰炸"）'),
      style_reference: z.string().optional().describe('参考文本样本，用于提取风格特征作为改写依据'),
      preserve_core: z.boolean().default(true).describe('是否保持核心情节和人物行为不变'),
      intensity: z.enum(['light', 'moderate', 'heavy']).default('moderate').describe('风格改写强度：轻度(微调语气)/中度(显著变化)/重度(完全重写)'),
    },
    async (params) => {
      const intensityLabels = {
        light: '轻度改写：保留原文大部分句子结构，调整用词和语气，让风格贴合目标',
        moderate: '中度改写：保留事件顺序和关键动作，重写句式、描写和对话，风格显著变化',
        heavy: '重度改写：仅保留核心事件，完全重写叙事方式、节奏和语言质感',
      };

      const rules = buildWritingRulesPrompt([
        'showDontTell', 'rhythm', 'dialogue', 'avoidance'
      ]);

      return {
        content: [{
          type: 'text',
          text: `# 风格改写

将以下原文改写为目标风格。${params.preserve_core ? '保持核心情节和人物行为不变，' : ''}变换语言质感。

## 目标风格
${params.target_style}

## 改写强度
${intensityLabels[params.intensity]}
${params.style_reference ? `\n## 风格参考样本\n${params.style_reference}\n\n请先从参考样本中提取以下6维风格签名：\n1. 词汇层（高频用词/形容词密度/动词精准度）\n2. 句式层（平均句长/短句vs长句比例/排比对偶密度）\n3. 标点节奏（逗号密度/句号密度/感叹号密度）\n4. 叙事层（对话占比/描写占比/心理描写密度/感官分布）\n5. 节奏层（段落长度/场景切换频率）\n6. 情感层（正负情感分布/外放vs内敛/浓度）\n\n提取后用该风格签名指导改写。` : ''}

## 原文
${params.original_text}

${rules}

## 输出要求
- 先输出改写后的完整文本
- 再输出【改写说明】，列出风格转换的3-5个关键改动点
`
        }]
      };
    }
  );
}

module.exports = { registerTextQualityTools };
