// 剧情架构 MCP 工具
const z = require('zod');
const { loadModule } = require('../module-loader');

function buildFullContent(sections) {
  let out = '';
  for (const s of sections) {
    out += `# ${s.title}\n\n`;
    out += s.text + '\n\n';
    for (const sub of s.subsections) {
      out += `## ${sub.title}\n\n${sub.text}\n\n`;
      for (const t of (sub.tables || [])) {
        out += '| ' + t.headers.join(' | ') + ' |\n';
        out += '|' + t.headers.map(() => '---').join('|') + '|\n';
        for (const row of t.rows) {
          out += '| ' + row.join(' | ') + ' |\n';
        }
        out += '\n';
      }
    }
  }
  return out;
}

function registerPlotArchitectureTools(server) {
  const mod = loadModule('03-plot-architecture.md');

  server.tool(
    'plot_architecture_guide',
    '获取剧情架构的完整方法论。包括三幕式结构、伏笔网络、节奏控制、钩子设计、信息增量规划等。',
    {
      section: z.enum(['all', 'structure', 'foreshadowing', 'rhythm', 'hooks', 'info_increment', 'template']).default('all').describe('需要获取的具体章节')
    },
    async ({ section }) => {
      if (mod.error) {
        return { content: [{ type: 'text', text: `模块加载失败: ${mod.error}` }] };
      }

      const sections = mod.sections;
      const titleMap = {
        all: [],
        structure: ['模块三：剧情架构'],
        foreshadowing: [],
        rhythm: [],
        hooks: [],
        info_increment: [],
        template: []
      };

      // 匹配所有包含关键词的章节
      const allSectionTitles = sections.map(s => s.title);
      for (const title of allSectionTitles) {
        if (title.includes('伏笔') || title.includes('伏笔网络')) titleMap.foreshadowing.push(title);
        if (title.includes('节奏') || title.includes('钩子') || title.includes('爽点密度')) titleMap.rhythm.push(title);
        if (title.includes('钩子强度') || title.includes('钩子')) titleMap.hooks.push(title);
        if (title.includes('信息增量') || title.includes('信息密度')) titleMap.info_increment.push(title);
        if (title.includes('模板') || title.includes('附录')) titleMap.template.push(title);
        if (title.includes('三幕') || title.includes('每卷得失') || title.includes('炸弹开头')) titleMap.structure.push(title);
      }

      let result = '';
      const selected = titleMap[section] || [];

      result += buildFullContent(sections.filter(s => selected.includes(s.title)));

      if (!result) {
        result = buildFullContent(sections);
      }

      return {
        content: [{ type: 'text', text: result }]
      };
    }
  );

  server.tool(
    'foreshadowing_network_design',
    '设计或分析伏笔网络。包括三层伏笔（短/中/长线）、伏笔埋设与回收规划。',
    {
      story_concept: z.string().describe('故事的核心概念或一句话梗概'),
      target_chapters: z.number().optional().describe('目标章节总数（用于伏笔密度规划）')
    },
    async ({ story_concept, target_chapters }) => {
      const foreshadowSections = mod.sections.filter(s =>
        s.title.includes('伏笔') || s.title.includes('伏笔网络')
      );
      const guide = buildFullContent(foreshadowSections);

      return {
        content: [{
          type: 'text',
          text: `# 伏笔网络设计\n\n## 故事概念\n${story_concept}\n${target_chapters ? `\n目标章节数：${target_chapters}章` : ''}\n\n---\n\n${guide}\n\n请根据以上方法论，为这个故事设计三层伏笔网络（短线/中线/长线），并规划每个伏笔的埋设与回收时机。`
        }]
      };
    }
  );
}

module.exports = { registerPlotArchitectureTools };
